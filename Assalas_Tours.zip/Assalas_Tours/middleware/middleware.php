<?php
class middleware {
    public static function isAuthenticated() {
        session_start();
        if (!isset($_SESSION['user'])) {
            header("Location: connexion.php");
            exit;
        }
    }
}
?>