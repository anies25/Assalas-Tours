<?php
session_start();
require_once '../models/FeedbackModel.php';

if (!isset($_SESSION['user'])) {
    header("Location: connexion.php");
    exit;
}


$type = htmlspecialchars($_GET['type'] ?? 'hebergement');
$typeId = intval($_GET['id'] ?? 0);

$feedbackModel = new FeedbackModel();
$feedbacks = $feedbackModel->getFeedbacksByType($type, $typeId);
$moyenneNote = $feedbackModel->getMoyenneNote($type, $typeId);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedbacks</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="container mt-5">
        <h1 class="text-center">Feedbacks</h1>
        <h3 class="text-center">Note moyenne : <?= number_format($moyenneNote, 1) ?>/5</h3>

        <div class="mt-4">
            <?php if (!empty($feedbacks)): ?>
                <?php foreach ($feedbacks as $feedback): ?>
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($feedback['user_nom']); ?></h5>
                            <p class="card-text"><?= htmlspecialchars($feedback['commentaire']); ?></p>
                            <p class="card-text"><strong>Note :</strong> <?= htmlspecialchars($feedback['note']); ?>/5</p>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-center">Aucun feedback disponible.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>