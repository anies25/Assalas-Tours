<?php
session_start();


if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = [];
}


if (isset($_GET['remove_id'])) {
    $remove_id = intval($_GET['remove_id']);
    foreach ($_SESSION['panier'] as $key => $item) {
        if ($item['id'] === $remove_id) { 
            unset($_SESSION['panier'][$key]);
            $_SESSION['panier'] = array_values($_SESSION['panier']); 
            break;
        }
    }
    header("Location: panier.php"); 
    exit;
}


$montant_total = array_reduce($_SESSION['panier'], function ($carry, $item) {
    return $carry + (isset($item['prix']) ? $item['prix'] : 0); 
}, 0);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panier</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Votre Panier</h1>
        <?php if (empty($_SESSION['panier'])): ?>
            <div class="alert alert-warning text-center mt-4">
                Votre panier est vide. <a href="hebergement.php">Parcourir les hébergements</a>.
            </div>
        <?php else: ?>
            <table class="table table-bordered mt-4">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Nom</th>
                        <th>Prix (€)</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($_SESSION['panier'] as $item): ?>
                        <tr>
                            <td>
                                <img src="../public/Image/<?= htmlspecialchars($item['photo']); ?>" alt="<?= htmlspecialchars($item['nom']); ?>" style="width: 100px;">
                            </td>
                            <td><?= htmlspecialchars($item['nom']); ?></td>
                            <td><?= number_format($item['prix'], 2); ?> €</td>
                            <td>
                                <a href="panier.php?remove_id=<?= $item['id']; ?>" class="btn btn-danger btn-sm">Supprimer</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="text-end">
                <h4>Total : <?= number_format($montant_total, 2); ?> €</h4>
                <a href="paiement.php" class="btn btn-primary">Passer au paiement</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>