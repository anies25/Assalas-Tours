<?php
require_once '../config/database.php';

class RendezvousModel {
    private $conn;

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function ajouterRendezvous($nom, $prenom, $email, $telephone, $message) {
        try {
            $query = "INSERT INTO rendezvous (nom, prenom, email, telephone, message) VALUES (:nom, :prenom, :email, :telephone, :message)";
            $stmt = $this->conn->prepare($query);

            $stmt->bindParam(':nom', $nom);
            $stmt->bindParam(':prenom', $prenom);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':telephone', $telephone);
            $stmt->bindParam(':message', $message);

            return $stmt->execute();
        } catch (PDOException $e) {
            echo "Erreur : " . $e->getMessage();
            return false;
        }
    }
}
?>