<?php
require_once 'models/Reservation.php';
require_once 'config/database.php';

class ReservationController {
    private $db;
    private $reservation;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->reservation = new Reservation($this->db);
    }

    public function creerReservation() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->reservation->client_id = $_POST['client_id'];
            $this->reservation->offre_id = $_POST['offre_id'];
            $this->reservation->date_reservation = date('Y-m-d H:i:s');

            if ($this->reservation->ajouter()) {
                header("Location: index.php?controller=ReservationController&action=afficherReservations");
            } else {
                echo "Erreur lors de la création de la réservation.";
            }
        } else {
            require_once 'views/reservations/create.php';
        }
    }

    public function afficherReservations() {
        $reservations = $this->reservation->lister();
        require_once 'views/reservations/index.php';
    }
}
?>