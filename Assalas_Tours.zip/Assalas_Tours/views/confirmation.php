<?php
session_start();


if (!isset($_SESSION['user'])) {
    header("Location: connexion.php");
    exit;
}


unset($_SESSION['panier']);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmation</title>
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="container mt-5">
        <h1 class="text-center">Merci pour votre achat !</h1>
        <p class="text-center">Votre paiement a été effectué avec succès.</p>
        <p class="text-center">Montant total : <strong><?php echo number_format($_GET['montant'], 2); ?> €</strong></p>
    </div>
</body>
</html>
