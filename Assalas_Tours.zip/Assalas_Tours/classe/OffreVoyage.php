<?php

class OffreVoyage{

    private $idOffre;
    private $type;
    private $destination;
    private $prix;
    private $description;
    private $disponibilite;

    public function __construct($id,$typ,$dest,$prx,$decr,$disp){

        $this->idOffre = $id;
        $this->type = $typ;
        $this->destination = $dest;
        $this->prix = $prx;
        $this->description = $desc;
        $this->disponibilite = $disp;
    }

    public function getIdOffre(){
        return $this->idOffre;
    }

    public function getType(){
        return $this->type;
    }
    public function setType($_typ){
        $this->type = $typ;
    }

    public function getDestination(){
        return $this->dest;
    }
    public function setDestination($_dest){
        $this->detination = $dest;
    }

    public function getPrix(){
        return $this->prix;
    }
    public function setPrix($_prx){
        $this->prix = $prx;
    }

    public function getDescription(){
        return $this->description;
    }
    public function setDescription($_desc){
        $this->description = $desc;
    }

    public function getDisponibilite(){
        return $this->disp;
    }
    public function setDisponibilite($_disp){
        $this->disponibilite = $disp;
    }


    public function ajouterOffre(){

    }

    public function supprimerOffre(){


    }

    public function modifierOffre(){


    }

    public function consulterOffre(){

        
    }

}