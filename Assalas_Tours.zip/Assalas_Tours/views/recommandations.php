
<?php

include "header.php";

?>




<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recommandations</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Vos Recommandations Personnalisées</h1>
        <div class="row mt-4">
            <?php if (!empty($recommandations)): ?>
                <?php foreach ($recommandations as $item): ?>
                    <div class="col-md-4 mb-3">
                        <div class="card">
                            <img src="../public/images/<?= htmlspecialchars($item['photo'] ?? 'default.jpg'); ?>" class="card-img-top" alt="<?= htmlspecialchars($item['nom']); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?= htmlspecialchars($item['nom']); ?></h5>
                                <p class="card-text"><?= htmlspecialchars($item['description'] ?? ''); ?></p>
                                <p class="text-muted">Prix : <?= htmlspecialchars($item['prix']); ?> €</p>
                                <a href="#" class="btn btn-primary">Voir Détails</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-center">Aucune recommandation pour le moment. Explorez nos offres pour en découvrir plus !</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>