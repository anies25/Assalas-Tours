<?php
  include "header.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire de Rendez-vous</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Formulaire de Rendez-vous</h1>
        <form action="process_rdv.php" method="POST">
           
            <div class="mb-3">
                <label for="nom" class="form-label">Nom</label>
                <input type="text" class="form-control" id="nom" name="nom" placeholder="Entrez votre nom" required>
            </div>
            
           
            <div class="mb-3">
                <label for="prenom" class="form-label">Prénom</label>
                <input type="text" class="form-control" id="prenom" name="prenom" placeholder="Entrez votre prénom" required>
            </div>
            
          
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Entrez votre email" required>
            </div>
            
          
            <div class="mb-3">
                <label for="telephone" class="form-label">Téléphone</label>
                <input type="text" class="form-control" id="telephone" name="telephone" placeholder="Entrez votre téléphone" required>
            </div>
            <div>
            <label for="piece_identite" class="form-label">Pièce d'identité canadienne (format PDF ou image)</label>
            <input type="file" class="form-control" id="piece_identite" name="piece_identite" accept=".pdf, image/*" required>
            </div>
          
            <div class="mb-3">
                <label for="destination" class="form-label">Destination</label>
                <select class="form-select" id="destination" name="destination" required>
                    <option value="" selected disabled>Choisissez une destination</option>
                    <option value="Paris">Paris</option>
                    <option value="New York">New York</option>
                    <option value="Tokyo">Tokyo</option>
                    <option value="Istanbul">Istanbul</option>
                    <option value="Le Caire">Le Caire</option>
                </select>
            </div>
            
         
            <div class="mb-3">
                <label for="type_question" class="form-label">Type de Question</label>
                <select class="form-select" id="type_question" name="type_question" required>
                    <option value="" selected disabled>Choisissez un type</option>
                    <option value="Réservation">Réservation</option>
                    <option value="Annulation">Annulation</option>
                    <option value="Demande de renseignements">Demande de renseignements</option>
                    <option value="Autre">Autre</option>
                </select>
            </div>
            
            
            <div class="mb-3">
                <label for="message" class="form-label">Message</label>
                <textarea name="message" id="message" class="form-control" rows="4" placeholder="Votre message..."></textarea>
            </div>
            
          
            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-primary">Envoyer</button>
                <button type="reset" class="btn btn-danger">Réinitialiser</button>
            </div>
        </form>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>