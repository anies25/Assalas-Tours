<?php
session_start();


if (!isset($_SESSION['user'])) {
    header("Location: connexion.php");
    exit;
}


if (!isset($_SESSION['panier']) || empty($_SESSION['panier'])) {
    echo "Votre panier est vide.";
    exit;
}


$total = 0;
foreach ($_SESSION['panier'] as $item) {
    $total += $item['prix'];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paiement avec PayPal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="container mt-5">
        <h1 class="text-center">Paiement avec PayPal</h1>
        <p class="text-center">Montant total : <strong><?php echo number_format($total, 2); ?> €</strong></p>

        <div id="paypal-button-container" class="text-center"></div>
        <script src="https://www.paypal.com/sdk/js?client-id=AVzmRaOXAiqeBmPzsh4GNMQ79VKHVEBuL8q1qJp8XzEQVm8LlkXfTcuXYtzG1ITDoasUJmtXUQCj4BUQ&currency=EUR"></script>
        <script>
            paypal.Buttons({
                createOrder: function(data, actions) {
                    return actions.order.create({
                        purchase_units: [{
                            amount: {
                                value: '<?php echo number_format($total, 2); ?>' 
                            }
                        }]
                    });
                },
                onApprove: function(data, actions) {
                    return actions.order.capture().then(function(details) {
                        alert('Transaction réussie par ' + details.payer.name.given_name);
                        window.location.href = "merci.php"; 
                    });
                },
                onCancel: function (data) {
                    alert('Paiement annulé');
                }
            }).render('#paypal-button-container'); 
        </script>
    </div>
</body>
</html>
