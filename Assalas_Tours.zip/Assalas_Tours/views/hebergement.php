<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hébergements</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/Assalas_Tours/public/style.css">
</head>
<body>
    <?php
    require_once '../models/HebergementModel.php';

    $hebergementModel = new HebergementModel();

    $hebergementsParPage = 6; 
    $pageActuelle = isset($_GET['page']) ? intval($_GET['page']) : 1; 
    $offset = ($pageActuelle - 1) * $hebergementsParPage; 

    $hebergements = $hebergementModel->getHebergementsByPage($offset, $hebergementsParPage);
    $totalHebergements = $hebergementModel->getTotalCount();
    $totalPages = ceil($totalHebergements / $hebergementsParPage); 
    ?>

    <?php include 'header.php'; ?>

    <?php if (isset($_SESSION['user'])): ?>
        <h1 class="text-center my-4">Hébergements disponibles</h1>

        <div class="container">
            <div class="row">
                <?php foreach ($hebergements as $hebergement): ?>
                    <div class="col-md-4 mb-4">
                       
                        <form method="POST" action="ajouter_panier.php" style="display: inline;">
                            <input type="hidden" name="id" value="<?php echo $hebergement['id']; ?>">
                            <button type="submit" class="btn btn-primary mb-2">Ajouter au panier</button>
                        </form>
                   
                        <a href="details_hebergement.php?id=<?php echo $hebergement['id']; ?>" style="text-decoration: none; color: inherit;">
                            <div class="card">
                                <img src="../public/Image/<?php echo htmlspecialchars($hebergement['photo']); ?>" class="card-img-top" alt="Photo de <?php echo htmlspecialchars($hebergement['nom']); ?>" style="height: 200px; object-fit: cover;">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo htmlspecialchars($hebergement['nom']); ?></h5>
                                    <p class="card-text">Adresse : <?php echo htmlspecialchars($hebergement['adresse']); ?></p>
                                    <p class="card-text">Prix : <?php echo htmlspecialchars($hebergement['prix']); ?> €</p>
                                    <p class="card-text">Étoiles : <?php echo htmlspecialchars($hebergement['etoiles']); ?></p>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>

          
            <nav aria-label="Pagination">
                <ul class="pagination justify-content-center">
                    <?php for ($i = 1; $i <= $totalPages && $i <= 3; $i++): ?>
                        <li class="page-item <?php echo ($i == $pageActuelle) ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        </div>
    <?php endif; ?>
</body>
</html>
