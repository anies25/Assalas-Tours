<?php
require_once '../models/HebergementModel.php';


session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: connexion.php");
    exit;
}


$hebergementModel = new HebergementModel();
$hebergements = $hebergementModel->getAllHebergements();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gérer les Hébergements</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../public/style.css">

</head>
<body>
    <?php include 'header.php'; ?> 

    <div class="container mt-5">
    <h1 class="text-center mb-4">Gérer les Hébergements</h1>

    <div class="text-end mb-3">
        <a href="ajout_hebergement.php" class="btn btn-primary">Ajouter un nouvel hébergement</a>
    </div>

    <div class="table-container">
        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Nom</th>
                    <th>Adresse</th>
                    <th>Prix (€)</th>
                    <th>Étoiles</th>
                    <th>Photo</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($hebergements as $hebergement): ?>
                <tr>
                    <td><?php echo htmlspecialchars($hebergement['nom']); ?></td>
                    <td><?php echo htmlspecialchars($hebergement['adresse']); ?></td>
                    <td><?php echo htmlspecialchars($hebergement['prix']); ?> €</td>
                    <td><?php echo htmlspecialchars($hebergement['etoiles']); ?></td>
                    <td>
                        <img src="../public/Image/<?php echo htmlspecialchars($hebergement['photo']); ?>" alt="Photo de <?php echo htmlspecialchars($hebergement['nom']); ?>" class="hebergement-photo">
                    </td>
                    <td>
                        <a href="modifier_hebergement.php?id=<?php echo $hebergement['id']; ?>" class="btn btn-warning btn-sm">Modifier</a>
                        <a href="supprimer_hebergement.php?id=<?php echo $hebergement['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Êtes-vous sûr ?');">Supprimer</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
                </body>

                </html>