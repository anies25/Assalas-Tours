<?php
require_once '../config/database.php';

class RecommandationModel {
    private $conn;

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function getRecommandationsByUser($userId) {
       
        $query = "
            SELECT h.* 
            FROM hebergements h
            JOIN reservations r ON r.hebergement_id = h.id
            WHERE r.user_id = :userId
            UNION
            SELECT c.*
            FROM circuits c
            JOIN reservations r ON r.circuit_id = c.id
            WHERE r.user_id = :userId
            LIMIT 5";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>