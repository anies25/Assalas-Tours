<?php 
  include "header.php";

 

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vols - Bientôt disponible</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../public/Image/avion.jpg'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed; 
            height: 100vh;
            margin: 0;
            color: white;
            font-family: Arial, sans-serif;
        }

        
        .overlay {
            background-color: rgba(0, 0, 0, 0.6); 
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .message {
            text-align: center;
            z-index: 2; 
        }

        .message h1 {
            font-size: 3rem;
            margin-bottom: 20px;
        }

        .message p {
            font-size: 1.5rem;
            margin-bottom: 30px;
        }

        .btn {
            font-size: 1.2rem;
            padding: 10px 20px;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            color: white;
            text-transform: uppercase;
        }

        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <div class="overlay">
        <div class="message">
            <h1>Vols - Bientôt disponible</h1>
            <p>Notre service de réservation de vols sera bientôt opérationnel.<br> Restez connectés pour plus d'informations !</p>
            <a href="acceuil.php" class="btn">Retour à l'accueil</a>
        </div>
    </div>
</body>
</html>