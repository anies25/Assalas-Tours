<?php
require_once '../controlleur/InscriptionController.php';

$controller = new InscriptionController();
$controller->inscrire();
?>
