<?php
require_once '../config/database.php';

class ReservationModel {
    private $conn;

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

 
    public function ajouterReservation($type, $itemId, $userId, $dateReservation) {
        $query = "INSERT INTO reservations (type, item_id, user_id, date_reservation) VALUES (:type, :item_id, :user_id, :date_reservation)";
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':type', $type);
        $stmt->bindParam(':item_id', $itemId);
        $stmt->bindParam(':user_id', $userId);
        $stmt->bindParam(':date_reservation', $dateReservation);
        
        return $stmt->execute();
    }

 
    public function getReservationsByUser($userId) {
        $query = "SELECT r.id, r.type, r.date_reservation, 
                         c.nom AS circuit_nom, 
                         v.nom AS vol_nom, 
                         h.nom AS hebergement_nom 
                  FROM reservations r
                  LEFT JOIN circuits c ON r.type = 'circuit' AND r.item_id = c.id
                  LEFT JOIN vols v ON r.type = 'vol' AND r.item_id = v.id
                  LEFT JOIN hebergements h ON r.type = 'hebergement' AND r.item_id = h.id
                  WHERE r.user_id = :user_id
                  ORDER BY r.date_reservation DESC";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

 
    public function supprimerReservation($reservationId) {
        $query = "DELETE FROM reservations WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $reservationId, PDO::PARAM_INT);
        return $stmt->execute();
    }

 
    public function verifierReservation($userId, $itemId, $type) {
        $query = "SELECT COUNT(*) FROM reservations WHERE user_id = :user_id AND item_id = :item_id AND type = :type";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':item_id', $itemId, PDO::PARAM_INT);
        $stmt->bindParam(':type', $type);

        $stmt->execute();
        return $stmt->fetchColumn() > 0;
    }
}
?>