<?php
session_start();
require_once '../models/FeedbackModel.php';


if (!isset($_SESSION['user'])) {
    header("Location: connexion.php");
    exit;
}

$type = htmlspecialchars($_GET['type'] ?? 'hebergement');
$typeId = intval($_GET['id'] ?? 0);


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $commentaire = htmlspecialchars($_POST['commentaire']);
    $note = intval($_POST['note']);
    $userId = $_SESSION['user']['id'];

    $feedbackModel = new FeedbackModel();
    $result = $feedbackModel->ajouterFeedback($userId, $type, $typeId, $commentaire, $note);

    if ($result) {
        header("Location: feedback.php?type=$type&id=$typeId");
        exit;
    } else {
        $erreur = "Une erreur s'est produite lors de l'ajout du feedback.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Feedback</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="container mt-5">
        <h1 class="text-center">Ajouter un Feedback</h1>

        <?php if (isset($erreur)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($erreur); ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="mb-3">
                <label for="commentaire" class="form-label">Commentaire</label>
                <textarea class="form-control" id="commentaire" name="commentaire" rows="4" required></textarea>
            </div>
            <div class="mb-3">
                <label for="note" class="form-label">Note (sur 5)</label>
                <select class="form-select" id="note" name="note" required>
                    <option value="" disabled selected>Choisissez une note</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Envoyer</button>
        </form>
    </div>
</body>
</html>