<?php
class Admin extends Utilisateur{
    private $permission;

    public function __construct ($n,$p,$e,$mdp,$r,$per){
        parent:: __construct($n,$p,$e,$mdp,'admin');

        $this->permission = $per;
    }

    public function getPermission(){
        return $this->permission;
    }
    public function setPermission($_per){
        $this->permission = $_per;
    }

    public function gererutilisateur(){

    }

    public function gererreservation(){

    }

    public function gereroffre(){

    }
}