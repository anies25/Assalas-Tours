<?php
require_once '../models/UtilisateurModel.php';

if (isset($_GET['token'])) {
    $token = $_GET['token'];
    $model = new UtilisateurModel();
    $utilisateur = $model->trouverParToken($token);

    if (!$utilisateur) {
        echo "Lien de réinitialisation invalide ou expiré.";
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nouveauMotDePasse = password_hash($_POST['nouveau_mot_de_passe'], PASSWORD_DEFAULT);
        
       
        $model->mettreAJourMotDePasse($utilisateur['id'], $nouveauMotDePasse);

   
        $model->supprimerToken($utilisateur['id']);

        echo "Mot de passe réinitialisé avec succès.";
        header("Location: connexion.php");
        exit;
    }
} else {
    echo "Lien de réinitialisation manquant.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation de mot de passe</title>
    <link rel="stylesheet" href="../public/style.css">
</head>
<body>
    <div class="login-container">
        <form method="POST" action="">
            <h2>Réinitialiser le mot de passe</h2>
            <label for="nouveau_mot_de_passe">Nouveau mot de passe :</label>
            <input type="password" id="nouveau_mot_de_passe" name="nouveau_mot_de_passe" placeholder="Nouveau mot de passe" required>
            <button type="submit" class="login-btn">Réinitialiser</button>
        </form>
    </div>
</body>
</html>
