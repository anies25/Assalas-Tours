<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="../public/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
</head>
<body>
<div class="signup-section">
    <div class="signup-container">
       
        <div class="signup-form">
            <h2>Sign up</h2>
            <form action="../controlleur/InscriptionController.php" method="POST">
    <div class="form-group">
        <label for="nom"><i class="fa fa-user"></i></label>
        <input type="text" id="nom" name="nom" placeholder="Votre nom" required>
    </div>
    <div class="form-group">
        <label for="prenom"><i class="fa fa-user"></i></label>
        <input type="text" id="prenom" name="prenom" placeholder="Votre prénom" required>
    </div>
    <div class="form-group">
        <label for="email"><i class="fa fa-envelope"></i></label>
        <input type="email" id="email" name="email" placeholder="Votre email" required>
    </div>
    <div class="form-group">
        <label for="mot_de_passe"><i class="fa fa-lock"></i></label>
        <input type="password" id="mot_de_passe" name="mot_de_passe" placeholder="Mot de passe" required>
    </div>
    <div class="form-group">
        <label for="confirm-password"><i class="fa fa-lock"></i></label>
        <input type="password" id="confirm-password" name="confirm-password" placeholder="Confirmez votre mot de passe" required>
    </div>
    <button type="submit" class="btn">Register</button>
</form>

<p class="already-member">
    <a href="../views/connexion.php" class="link-to-login">I am already a member</a>
</p>
        </div>
       
        <div class="signup-image">
            <img src="../public/Image/publicite_11.jpg" alt="Sign up illustration">
        </div>
    </div>
</div>
</body>
</html>