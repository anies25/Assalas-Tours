<?php
require_once '../controllers/FeedbackController.php';

$controller = new FeedbackController();

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user'])) {
   
    $userId = $_SESSION['user']['id'];
    $type = htmlspecialchars($_POST['type']);
    $typeId = intval($_POST['type_id']);
    $commentaire = htmlspecialchars($_POST['commentaire']);
    $note = intval($_POST['note']);

    if ($note >= 1 && $note <= 5) {
        $message = $controller->ajouterFeedback($userId, $type, $typeId, $commentaire, $note);
        header('Location: ../views/feedback_success.php?message=' . urlencode($message));
    } else {
        header('Location: ../views/feedback_error.php?message=' . urlencode("Note invalide."));
    }
} elseif (isset($_GET['action']) && $_GET['action'] === 'supprimer') {
   
    if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin') {
        $feedbackId = intval($_GET['id']);
        $message = $controller->supprimerFeedback($feedbackId);
        header('Location: ../views/admin/feedbacks_admin.php?message=' . urlencode($message));
    } else {
        header('Location: ../views/connexion.php');
    }
}
?>