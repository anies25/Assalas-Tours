<?php
session_start();
require_once '../models/HebergementModel.php';


if (!isset($_POST['id'])) {
    die("ID d'hébergement non spécifié !");
}

$id = intval($_POST['id']);


$hebergementModel = new HebergementModel();
$hebergement = $hebergementModel->getHebergementById($id);

if (!$hebergement) {
    die("Hébergement introuvable !");
}


if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = [];
}


$_SESSION['panier'][] = [
    'id' => $hebergement['id'],
    'nom' => $hebergement['nom'],
    'prix' => $hebergement['prix'],
    'photo' => $hebergement['photo'],
];


header("Location: panier.php");
exit;
?>
