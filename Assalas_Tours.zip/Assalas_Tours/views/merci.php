<?php
session_start();
unset($_SESSION['panier']); 
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Merci</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="container text-center mt-5">
        <h1>Merci pour votre paiement !</h1>
        <p>Votre transaction a été réalisée avec succès. Nous vous remercions pour votre achat.</p>
        <a href="acceuil.php" class="btn btn-primary">Retour à l'accueil</a>
    </div>
</body>
</html>
