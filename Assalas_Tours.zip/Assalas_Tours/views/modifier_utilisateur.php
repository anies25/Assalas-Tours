<?php
require_once '../models/UtilisateurModel.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $utilisateurModel = new UtilisateurModel();
    $utilisateur = $utilisateurModel->getUtilisateurById($id);

    if (!$utilisateur) {
        echo "Utilisateur introuvable.";
        exit;
    }
} else {
    echo "ID d'utilisateur manquant.";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = htmlspecialchars($_POST['nom']);
    $prenom = htmlspecialchars($_POST['prenom']);
    $email = htmlspecialchars($_POST['email']);
    $role = htmlspecialchars($_POST['role']);

    if ($utilisateurModel->modifierUtilisateur($id, $nom, $prenom, $email, $role)) {
        echo "Utilisateur modifié avec succès.";
        header("Location: admin_utilisateur.php");
        exit;
    } else {
        echo "Erreur lors de la modification.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier Utilisateur</title>
</head>
<body>
    <h1>Modifier Utilisateur</h1>
    <form method="POST" action="">
        <label>Nom :</label><br>
        <input type="text" name="nom" value="<?php echo htmlspecialchars($utilisateur['nom']); ?>" required><br>
        <label>Prénom :</label><br>
        <input type="text" name="prenom" value="<?php echo htmlspecialchars($utilisateur['prenom']); ?>" required><br>
        <label>Email :</label><br>
        <input type="email" name="email" value="<?php echo htmlspecialchars($utilisateur['email']); ?>" required><br>
        <label>Rôle :</label><br>
        <select name="role" required>
            <option value="client" <?php if ($utilisateur['role'] === 'client') echo 'selected'; ?>>Client</option>
            <option value="admin" <?php if ($utilisateur['role'] === 'admin') echo 'selected'; ?>>Admin</option>
        </select><br>
        <button type="submit">Modifier</button>
    </form>
</body>
</html>
