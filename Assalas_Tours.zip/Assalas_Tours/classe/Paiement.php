<?php

class Paiement{
    private $idPaiement;
    private $montant;
    private $datePaiement;
    private $statut;
    private $modePaiement;


    public function __construct($idP,$mnt,$dP,$stt,$mP){
        $this->idPaiement = $idP;
        $this->montant = $mnt;
        $this->datePaiement = $dp;
        $this->statut = $stt;
        $this->modePaiement = $mP;
    }

    public function getIdPaiement(){
        return $this->idPaiement;
    
    }

    public function getMontant(){
        return $this->montantat;
    
    }
    public function setMontant($_mnt){
        $this->montant = $mnt;
    }

    public function getDatePaiement(){
        return $this->datePaiement;
    }

    public function getStatut(){
        return $this->statut;
    
    }

    public function setStatut($_stt){
        $this->statut = $stt;
    }

    public function getModePaiement(){
        return $this->modePaiement;
    
    }
    public function setModePaiement($_mP){
        $this->modePaiement = $mP;
    }


    public function effectuerPaiement(){


    }

    public function rembourser(){

        
    }
}