<?php
require_once '../models/RendezvousModel.php';

class RdvController {
    public function creerRendezvous() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nom = $_POST['nom'];
            $prenom = $_POST['prenom'];
            $email = $_POST['email'];
            $telephone = $_POST['telephone'];
            $message = $_POST['message'];

            $model = new RendezvousModel();
            $result = $model->ajouterRendezvous($nom, $prenom, $email, $telephone, $message);

            if ($result) {
                header("Location: /Assalas_Tours/views/success.php");
            } else {
                echo "Erreur lors de l'ajout du rendez-vous.";
            }
        }
    }
}

if (isset($_GET['action']) && $_GET['action'] === 'creer') {
    $controller = new RdvController();
    $controller->creerRendezvous();
}
?>