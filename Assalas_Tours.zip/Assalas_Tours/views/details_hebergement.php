<?php
session_start();
require_once '../models/HebergementModel.php';


if (!isset($_GET['id'])) {
    echo "ID d'hébergement manquant.";
    exit;
}

$id = intval($_GET['id']);


$hebergementModel = new HebergementModel();


$hebergement = $hebergementModel->getHebergementById($id);

if (!$hebergement) {
    echo "Hébergement introuvable.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails de l'hébergement</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'header.php'; ?> 

    <div class="container my-5">
        <h1 class="text-center"><?php echo htmlspecialchars($hebergement['nom']); ?></h1>
        <div class="row">
            <div class="col-md-6">
                <img src="../public/Image/<?php echo htmlspecialchars($hebergement['photo']); ?>" class="img-fluid" alt="Photo de <?php echo htmlspecialchars($hebergement['nom']); ?>">
            </div>
            <div class="col-md-6">
                <h3>Description</h3>
                <p><strong>Adresse :</strong> <?php echo htmlspecialchars($hebergement['adresse']); ?></p>
                <p><strong>Prix :</strong> <?php echo htmlspecialchars($hebergement['prix']); ?> €</p>
                <p><strong>Étoiles :</strong> <?php echo htmlspecialchars($hebergement['etoiles']); ?></p>
                <form method="POST" action="ajouter_panier.php">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <button type="submit" class="btn btn-success">Ajouter au panier</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
