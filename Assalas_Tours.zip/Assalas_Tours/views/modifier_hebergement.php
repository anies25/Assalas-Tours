<?php
require_once '../models/HebergementModel.php';


if (isset($_GET['id'])) {
    $id = intval($_GET['id']); 
    $hebergementModel = new HebergementModel();
    
   
    $hebergement = $hebergementModel->getHebergementById($id);

   
    if (!$hebergement) {
        echo "Hébergement introuvable.";
        exit;
    }
} else {
    echo "ID d'hébergement manquant.";
    exit;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = htmlspecialchars($_POST['nom']);
    $adresse = htmlspecialchars($_POST['adresse']);
    $prix = floatval($_POST['prix']);
    $etoiles = intval($_POST['etoiles']);
    $photo = htmlspecialchars($_POST['photo']); 

   
    if ($hebergementModel->modifierHebergement($id, $nom, $adresse, $prix, $etoiles, $photo)) {
     
        header("Location: admin_hebergement.php?message=modification_succes");
        exit;
    } else {
        $erreur = "Erreur lors de la modification.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier Hébergement</title>
</head>
<body>
    <h1>Modifier Hébergement</h1>

  
    <?php if (isset($erreur)): ?>
        <p style="color: red;"><?php echo htmlspecialchars($erreur); ?></p>
    <?php endif; ?>

    <form method="POST" action="">
        <label>Nom :</label><br>
        <input type="text" name="nom" value="<?php echo htmlspecialchars($hebergement['nom'] ?? ''); ?>" required><br>

        <label>Adresse :</label><br>
        <input type="text" name="adresse" value="<?php echo htmlspecialchars($hebergement['adresse'] ?? ''); ?>" required><br>

        <label>Prix :</label><br>
        <input type="number" step="0.01" name="prix" value="<?php echo htmlspecialchars($hebergement['prix'] ?? ''); ?>" required><br>

        <label>Étoiles :</label><br>
        <input type="number" name="etoiles" value="<?php echo htmlspecialchars($hebergement['etoiles'] ?? ''); ?>" required><br>

        <label>Photo :</label><br>
        <input type="text" name="photo" value="<?php echo htmlspecialchars($hebergement['photo'] ?? ''); ?>"><br>

        <button type="submit">Modifier</button>
    </form>
</body>
</html>
