<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmation</title>
</head>
<body>
    <h1>Merci pour votre rendez-vous !</h1>
    <p>Nous vous contacterons sous peu pour confirmer les détails.</p>
    <a href="dashboard/Assalas_Tours/views/acceuil.php">Retour à l'accueil</a>
</body>
</html>