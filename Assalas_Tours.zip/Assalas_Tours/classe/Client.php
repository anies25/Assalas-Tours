<?php
class Client extends Utilisateur{
    private $historiqueReservations = [];

    public function __construct($n,$p,$e,$mdp,$r){
    parent:: __construct($n,$p,$e,$mdp,'client');
        
    $this->historiqueReservation=[];

    }



    public function getHistoriqueReservations() {
        return $this->historiqueReservations;
    }

  
    public function setHistoriqueReservations($historique) {
        $this->historiqueReservations = $historique;
    }

    
    public function effectuerReservation(){

    }

    public function consulterHistorique(){

    }

    public function annulerReservation(){

    }
}