# Assalas Tours - Application Web d'Agence de Voyage

## Description
**Assalas Tours** est une application web conçue pour simplifier la gestion des services d'une agence de voyage. Elle permet aux utilisateurs de rechercher et réserver des voyages, tout en offrant aux administrateurs un outil puissant pour gérer les destinations, les réservations et les utilisateurs. Ce projet met l'accent sur une interface intuitive et des fonctionnalités robustes.

---

## Fonctionnalités Principales
### Pour les utilisateurs :
- Navigation fluide entre différentes catégories de voyages.
- Affichage détaillé des informations sur les destinations, y compris :
  - Photos des lieux.
  - Description des voyages.
  - Prix et disponibilités.
- Système de réservation simple et rapide.
- Création de compte et gestion du profil utilisateur.

### Pour les administrateurs :
- Ajout, modification et suppression de destinations.
- Gestion des utilisateurs et des réservations.
- Tableaux de bord pour suivre les statistiques clés.

---

## Technologies Utilisées
- **Frontend :**
  - HTML, CSS, Bootstrap : pour le design et une expérience utilisateur responsive.
  - JavaScript : pour les interactions dynamiques.
- **Backend :**
  - PHP (avec PDO) : pour la logique métier et la gestion des requêtes.
- **Base de Données :**
  - MySQL : pour stocker les informations sur les destinations, les utilisateurs et les réservations.

---

## Structure du Projet
- **Frontend :**
  - `/public` : Contient les fichiers HTML, CSS et JavaScript.
  - `/assets` : Images et autres ressources statiques.
- **Backend :**
  - `/includes` : Contient les fichiers PHP pour la connexion à la base de données et les fonctionnalités dynamiques.
  - `/controllers` : Gestion des requêtes et des opérations métier.
- **Base de données :**
  - Tables principales : 'hebergement','commande','feedback','recommandation','reseervation',rendezvous',utilisateur'.

---

## Installation et Configuration
1. Clonez le dépôt :
   ```bash
   git clone https://github.com/votre-nom-utilisateur/assalas-tours.git
