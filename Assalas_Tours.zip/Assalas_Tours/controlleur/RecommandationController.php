<?php
require_once '../models/RecommandationModel.php';

class RecommandationController {
    private $model;

    public function __construct() {
        $this->model = new RecommandationModel();
    }

    public function afficherRecommandations($userId) {
        $recommandations = $this->model->getRecommandationsByUser($userId);
        include '../views/recommandations.php';
    }
}


session_start();
if (isset($_SESSION['user'])) {
    $controller = new RecommandationController();
    $controller->afficherRecommandations($_SESSION['user']['id']);
} else {
    header('Location: connexion.php');
}
?>