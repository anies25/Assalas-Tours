<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = htmlspecialchars($_POST['email']);
    
  
    require_once '../models/UtilisateurModel.php';
    $model = new UtilisateurModel();
    $utilisateur = $model->trouverParEmail($email); 

    if ($utilisateur) {
       
        $token = bin2hex(random_bytes(32));
        
      
        $model->sauvegarderToken($utilisateur['id'], $token);

        $resetLink = "http://localhost/dashboard/Assalas_Tours/views/motdepasse_renitialise.php?token=" . $token;


        echo "Lien de réinitialisation : <a href='$resetLink'>$resetLink</a>";
    } else {
        echo "Aucun compte n'est associé à cet email.";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mot de passe oublié</title>
    <link rel="stylesheet" href="../public/style.css">
</head>
<body>
    <div class="login-container">
        <form method="POST" action="">
            <h2>Mot de passe oublié</h2>
            <label for="email">Entrez votre adresse email :</label>
            <input type="email" id="email" name="email" placeholder="Votre email" required>
            <button type="submit" class="login-btn">Envoyer</button>
        </form>
    </div>
</body>
</html>
