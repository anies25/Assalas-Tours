<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../models/RendezvousModel.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  
    $nom = htmlspecialchars($_POST['nom']);
    $prenom = htmlspecialchars($_POST['prenom']);
    $email = htmlspecialchars($_POST['email']);
    $telephone = htmlspecialchars($_POST['telephone']);
    $message = htmlspecialchars($_POST['message']);

    $rendezvousModel = new RendezvousModel(); 
    $result = $rendezvousModel->ajouterRendezvous($nom, $prenom, $email, $telephone, $message);

    if ($result) {
      
        echo "
        <!DOCTYPE html>
        <html lang='fr'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Rendez-vous confirmé</title>
            <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
        </head>
        <body class='bg-light'>
            <div class='container mt-5'>
                <div class='alert alert-success text-center'>
                    <h3>Votre rendez-vous a été enregistré avec succès !</h3>
                </div>
                <div class='card mx-auto' style='max-width: 600px;'>
                    <div class='card-header bg-primary text-white text-center'>
                        <h5>Récapitulatif de votre demande</h5>
                    </div>
                    <div class='card-body'>
                        <p><strong>Nom :</strong> $nom</p>
                        <p><strong>Prénom :</strong> $prenom</p>
                        <p><strong>Email :</strong> $email</p>
                        <p><strong>Téléphone :</strong> $telephone</p>
                        <p><strong>Message :</strong> $message</p>
                    </div>
                    <div class='card-footer text-center'>
                        <a href='/Assalas_Tours/views/rdv.php' class='btn btn-primary'>Retour</a>
                    </div>
                </div>
            </div>
            <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js'></script>
        </body>
        </html>
        ";
    } else {
        echo "
        <div class='alert alert-danger text-center'>
            Une erreur est survenue lors de l'enregistrement. Veuillez réessayer.
        </div>";
    }
} else {
    echo "<h3 style='color: red; text-align: center;'>Méthode non autorisée.</h3>";
}
?>