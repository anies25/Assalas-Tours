<?php
require_once '../models/UtilisateurModel.php';
require_once '../classe/Utilisateur.php';

class InscriptionController {
    public function inscrire() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            
            if ($_POST['mot_de_passe'] !== $_POST['confirm-password']) {
                echo "Les mots de passe ne correspondent pas.";
                return;
            }

            $nom = htmlspecialchars($_POST['nom']);
            $prenom = htmlspecialchars($_POST['prenom']);
            $email = htmlspecialchars($_POST['email']);
            $motDePasse = $_POST['mot_de_passe'];
            $role = 'client';

            $utilisateur = new Utilisateur($nom, $prenom, $email, $motDePasse, $role);
            $model = new UtilisateurModel();

            if ($model->ajouterUtilisateur($utilisateur)) {
                header("Location: ../views/connexion.php"); 
                exit;
            } else {
                echo "Erreur : L'inscription a échoué.";
            }
        }
    }
}


$controller = new InscriptionController();
$controller->inscrire();

?>
