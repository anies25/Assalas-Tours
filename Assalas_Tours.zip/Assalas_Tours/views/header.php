<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assalas Tours</title>
   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../public/style.css">
</head>
<body>
   
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="acceuil.php">
                <img src="../public/Image/Logo.png" alt="Logo ASSALA" style="width: 150px;">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                  
                    <li class="nav-item"><a class="nav-link" href="acceuil.php">Accueil</a></li>
                    <li class="nav-item"><a class="nav-link" href="hebergement.php">Hébergements</a></li>
                    <li class="nav-item"><a class="nav-link" href="vols.php">Vols</a></li>
                    <li class="nav-item"><a class="nav-link" href="rdv.php">Rendez-vous</a></li>
                    <li class="nav-item"><a class="nav-link" href="circuit.php">Circuits</a></li>

                   
                    <?php if (isset($_SESSION['user']) && $_SESSION['user']['role'] !== 'admin'): ?>
                        <li class="nav-item"><a class="nav-link" href="historique.php">Historique</a></li>
                        <li class="nav-item"><a class="nav-link" href="panier.php">Panier</a></li>
                        <li class="nav-item"><a class="nav-link" href="recommandations.php">Recommandations</a></li>
                    <?php endif; ?>

              
                    <?php if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin'): ?>
                        <li class="nav-item"><a class="nav-link" href="admin.php">Espace Admin</a></li>
                    <?php endif; ?>
                </ul>
               
                <div class="ms-auto">
                    <?php if (isset($_SESSION['user'])): ?>
                     
                        <button class="btn btn-light ms-2" onclick="window.location.href='logout.php'">Se déconnecter</button>
                    <?php else: ?>
                        
                        <button class="btn btn-warning ms-3" onclick="window.location.href='inscription.php'">S'inscrire</button>
                        <button class="btn btn-light ms-2" onclick="window.location.href='connexion.php'">Se connecter</button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
</body>
</html>