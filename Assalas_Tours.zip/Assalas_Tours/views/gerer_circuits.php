<?php
session_start();


if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../views/connexion.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gérer les circuits</title>
    <link rel="stylesheet" href="../public/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="container mt-5 text-center">
        <h1 class="text-primary">Gestion des circuits</h1>
        <p class="mt-3 text-secondary">Cette fonctionnalité sera disponible très prochainement. Revenez bientôt !</p>
        <img src="../public/Image/circuit.png" alt="Circuits bientôt disponibles" class="img-fluid mt-3" style="max-width: 400px;">
    </div>
   
</body>
</html>