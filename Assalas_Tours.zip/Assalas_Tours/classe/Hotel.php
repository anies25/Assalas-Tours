<?php

class Hotel extends OffreVoyage{

    private $nomHotel;
    private $adresse;
    private $nbrEtoile;


    public function __construct($id,$typ,$dest,$prx,$decr,$disp,$nh,$ads,$nbr)
    {
        parent:: __construct($id,$typ,$dest,$prx,$decr,$disp);

        $this->nomHotel = $nh;
        $this->adresse = $ads;
        $this->nbrEtoile = $nbr;
    }

    public function getNomHotel(){
        return $this->nomHotel;
    }
    public function setNomHotel(){
        return $this->nomHotel = $nh;
    }

    public function getAdresse(){
        return $this->adresse;
    }
    public function setAdresse(){
        return $this->adresse = $ads;
    }


    public function consulter(){

    }

    public function chambreDispo(){
        
    }

}