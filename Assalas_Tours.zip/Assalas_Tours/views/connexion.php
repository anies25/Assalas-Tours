<?php
session_start();
require_once '../models/UtilisateurModel.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = htmlspecialchars($_POST['email']);
    $motDePasse = $_POST['mot_de_passe'];

    $model = new UtilisateurModel();
    $utilisateur = $model->verifierConnexion($email, $motDePasse);

    if ($utilisateur) {
        $_SESSION['user'] = $utilisateur;

    
        if ($utilisateur['role'] === 'admin') {
            header("Location: admin.php");
        } else {
            header("Location: acceuil.php");
        }
        exit;
    } else {
        echo "<pre>Email ou mot de passe incorrect.</pre>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>

    <link rel="stylesheet" href="../public/style.css"> 
</head>
<body>
    <div class="login-container">
        <div class="login-image"> 
            <img src="../public/Image/publicite_5.jpg" alt ="Login Image">
        </div>
        <div class="login-form">
            <div class="form-header">
                <img src="../public/Image/Logo.png" alt="Logo" class="logo">
               
                <p>Sign into your account</p>
            </div>
            <form method="POST" action="">
                <label for="email">Email address</label>
                <input type="email" id="email" name="email" placeholder="Email address" required>
                <label for="password">Password</label>
                <input type="password" id="password" name="mot_de_passe" placeholder="Password" required>
                <button type="submit" class="login-btn">LOGIN</button>
                <div class="form-footer">
                    <a href="../views/motdepasse-oublie.php">Forgot password?</a>
                    <p>Don't have an account? <a href="../views/inscription.php">Register here</a></p>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
