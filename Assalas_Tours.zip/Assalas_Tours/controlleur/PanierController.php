<?php
require_once 'models/Panier.php';
require_once 'config/database.php';

class PanierController {
    private $db;
    private $panier;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->panier = new Panier($this->db);
    }

    public function ajouterAuPanier() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->panier->client_id = $_POST['client_id'];
            $this->panier->produit_id = $_POST['produit_id'];
            $this->panier->quantite = $_POST['quantite'];

            if ($this->panier->ajouter()) {
                header("Location: index.php?controller=PanierController&action=afficherPanier");
            } else {
                echo "Erreur lors de l'ajout au panier.";
            }
        }
    }

    public function afficherPanier() {
        $panier = $this->panier->lister($_GET['client_id']);
        require_once 'views/panier/index.php';
    }

    public function supprimerDuPanier() {
        if (isset($_GET['id'])) {
            if ($this->panier->supprimer($_GET['id'])) {
                header("Location: index.php?controller=PanierController&action=afficherPanier");
            } else {
                echo "Erreur lors de la suppression du produit.";
            }
        }
    }
}
?>