<?php
require_once '../config/database.php';

class FeedbackModel {
    private $conn;

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function ajouterFeedback($userId, $type, $typeId, $commentaire, $note) {
        try {
            $query = "INSERT INTO feedbacks (user_id, type, type_id, commentaire, note) VALUES (:user_id, :type, :type_id, :commentaire, :note)";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':type', $type, PDO::PARAM_STR);
            $stmt->bindParam(':type_id', $typeId, PDO::PARAM_INT);
            $stmt->bindParam(':commentaire', $commentaire, PDO::PARAM_STR);
            $stmt->bindParam(':note', $note, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (PDOException $e) {
            echo "Erreur : " . $e->getMessage();
            return false;
        }
    }

    public function getFeedbacksByType($type, $typeId) {
        try {
            $query = "SELECT f.*, u.nom AS user_nom 
                      FROM feedbacks f
                      JOIN utilisateurs u ON f.user_id = u.id
                      WHERE f.type = :type AND f.type_id = :type_id
                      ORDER BY f.date_creation DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':type', $type, PDO::PARAM_STR);
            $stmt->bindParam(':type_id', $typeId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            echo "Erreur : " . $e->getMessage();
            return [];
        }
    }

    public function getMoyenneNote($type, $typeId) {
        try {
            $query = "SELECT AVG(note) AS moyenne_note FROM feedbacks WHERE type = :type AND type_id = :type_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':type', $type, PDO::PARAM_STR);
            $stmt->bindParam(':type_id', $typeId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC)['moyenne_note'];
        } catch (PDOException $e) {
            echo "Erreur : " . $e->getMessage();
            return null;
        }
    }

    public function supprimerFeedback($feedbackId) {
        try {
            $query = "DELETE FROM feedbacks WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $feedbackId, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (PDOException $e) {
            echo "Erreur : " . $e->getMessage();
            return false;
        }
    }
}
?>