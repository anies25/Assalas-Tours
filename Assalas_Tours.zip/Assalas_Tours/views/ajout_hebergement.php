<?php
require_once '../models/HebergementModel.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = htmlspecialchars($_POST['nom']);
    $adresse = htmlspecialchars($_POST['adresse']);
    $prix = floatval($_POST['prix']);
    $etoiles = intval($_POST['etoiles']);

   
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $photoTmpName = $_FILES['photo']['tmp_name'];
        $photoName = basename($_FILES['photo']['name']);
        $photoPath = '../public/Image/' . $photoName;

     
        if (move_uploaded_file($photoTmpName, $photoPath)) {
            $hebergementModel = new HebergementModel();
            if ($hebergementModel->ajouterHebergement($nom, $adresse, $prix, $etoiles, $photoName)) {
                echo "Hébergement ajouté avec succès.";
                header("Location: admin_hebergement.php");
                exit;
            } else {
                echo "Erreur lors de l'ajout de l'hébergement.";
            }
        } else {
            echo "Erreur lors du téléchargement de l'image.";
        }
    } else {
        echo "Veuillez sélectionner une image valide.";
    }
}
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter Hébergement</title>
    <link rel="stylesheet" href="../public/style.css">

</head>
<body>
    <h1>Ajouter Hébergement</h1>
    <form method="POST" action="" enctype="multipart/form-data">
    <label>Nom :</label><br>
    <input type="text" name="nom" required><br>
    <label>Adresse :</label><br>
    <input type="text" name="adresse" required><br>
    <label>Prix :</label><br>
    <input type="number" step="0.01" name="prix" required><br>
    <label>Étoiles :</label><br>
    <input type="number" name="etoiles" required><br>
    <label>Photo :</label><br>
    <input type="file" name="photo" accept="image/*" required><br>
    <button type="submit">Ajouter</button>
</form>

</body>
</html>
