<?php

class Vol extends OffreVoyage{

    private $numVol;
    private $compagnie;
    private $heuredepart;
    private $heurearrivee;


    public function __construct($id,$typ,$dest,$prx,$decr,$disp,$nv,$com,$hd,$ha){
        parent:: __construct($id,$typ,$dest,$prx,$decr,$disp);

        $this->numVol = $nv;
        $this->compagnie = $com;
        $this->heuredepart = $hd;
        $this->heurearrivee = $ha;
    }

    public function getNumVol(){
        return $this->numVol;
    }
    public function setNumVol($_nv){
        $this->numVol = $nv;
    }

    public function getCompagnie(){
        return $this->compagnie;
    }
    public function setCompagnie($_com){
        $this->compagnie = $com;
    }

    public function getHeuredepart(){
        return $this->heuredepart;
    }
    public function setHeuredepart($_nv){
        $this->heuredepart = $hd;
    }

    public function getHeurearrivee(){
        return $this->heurearrivee;
    }
    public function setHeurearrivee($_nv){
        $this->heurearrivee = $ha;
    }
}