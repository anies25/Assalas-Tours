<?php 
  include "header.php";

 

?>

   
    <div id="carouselExample" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="3000">
    <div class="carousel-inner">
     
        <?php for ($i = 1; $i <= 10; $i++): ?>
            <div class="carousel-item <?php echo $i === 1 ? 'active' : ''; ?>">
            <img src="../public/image/publicite_<?php echo $i; ?>.jpg" class="d-block w-100 vh-100" alt="Publicité <?php echo $i; ?>">
          
            
            </div>
        <?php endfor; ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Précédent</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Suivant</span>
    </button>
</div>

   
  
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php  include "footer.php"; ?>
