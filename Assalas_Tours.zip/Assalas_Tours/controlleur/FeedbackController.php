<?php
require_once '../models/FeedbackModel.php';

class FeedbackController {
    private $model;

    public function __construct() {
        $this->model = new FeedbackModel();
    }

 
    public function ajouterFeedback($userId, $type, $typeId, $commentaire, $note) {
        if ($this->model->ajouterFeedback($userId, $type, $typeId, $commentaire, $note)) {
            return "Votre feedback a été ajouté avec succès.";
        } else {
            return "Erreur lors de l'ajout du feedback.";
        }
    }

   
    public function afficherFeedbacks($type, $typeId) {
        $feedbacks = $this->model->getFeedbacksByType($type, $typeId);
        $moyenneNote = $this->model->getMoyenneNote($type, $typeId);
        include '../views/feedback_display.php'; 
    }


    public function supprimerFeedback($feedbackId) {
        if ($this->model->supprimerFeedback($feedbackId)) {
            return "Feedback supprimé avec succès.";
        } else {
            return "Erreur lors de la suppression du feedback.";
        }
    }
}


session_start();
$controller = new FeedbackController();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user'])) {

    $userId = $_SESSION['user']['id'];
    $type = htmlspecialchars($_POST['type']);
    $typeId = intval($_POST['type_id']);
    $commentaire = htmlspecialchars($_POST['commentaire']);
    $note = intval($_POST['note']);

    if ($note >= 1 && $note <= 5) {
        echo $controller->ajouterFeedback($userId, $type, $typeId, $commentaire, $note);
    } else {
        echo "La note doit être comprise entre 1 et 5.";
    }
}

if (isset($_GET['action']) && $_GET['action'] === 'supprimer') {
  
    if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin') {
        $feedbackId = intval($_GET['id']);
        echo $controller->supprimerFeedback($feedbackId);
    } else {
        echo "Accès refusé.";
    }
}
?>