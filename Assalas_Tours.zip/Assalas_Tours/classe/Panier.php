<?php

class Panier{
    private $total;
    private $item ;

    public function __construct($t,$i){

        $this->total = $t;
        $this->item =[];

    }
        public function getTotal(){
            return $this->total;
        }

        public function setTotal($_t){
            $this->total = $t;
        }

        public function getItem() {
            return $this-item;
        }
    
      
        public function setItem($_i) {
            $this->item = $i;
        }


        public function AjouterItem(){

        }
        public function SupprimerItem(){

        }
        public function CalculerTotal(){

        }


   
}
