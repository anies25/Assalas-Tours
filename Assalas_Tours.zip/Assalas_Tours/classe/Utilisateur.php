<?php

class Utilisateur {
    private $nom;
    private $prenom;
    private $email;
    private $motdepasse;
    private $role;

    public function __construct($nom, $prenom, $email, $motdepasse, $role = 'client') {
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->email = $email;
        $this->motdepasse = $motdepasse;
        $this->role = $role;
    }

    public function getNom() {
        return $this->nom;
    }

    public function getPrenom() {
        return $this->prenom;
    }

    public function getEmail() {
        return $this->email;
    }

    public function getMotdepasse() {
        return $this->motdepasse;
    }

    public function getRole() {
        return $this->role;
    }
}
