<?php
require_once '../config/database.php';

class HebergementModel {
    private $conn;

   
    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }


    public function getAllHebergements() {
        $query = "SELECT * FROM hebergements";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    


    public function getTotalCount() {
        $query = "SELECT COUNT(*) AS total FROM hebergements";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['total'];
    }

   
    public function getHebergementsByPage($offset, $limit) {
        $query = "SELECT * FROM hebergements LIMIT :offset, :limit";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

   
    public function getHebergementById($id) {
        $query = "SELECT * FROM hebergements WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    

   
    public function modifierHebergement($id, $nom, $adresse, $prix, $etoiles, $photo) {
        $query = "UPDATE hebergements SET nom = :nom, adresse = :adresse, prix = :prix, etoiles = :etoiles, photo = :photo WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':nom', $nom);
        $stmt->bindParam(':adresse', $adresse);
        $stmt->bindParam(':prix', $prix);
        $stmt->bindParam(':etoiles', $etoiles);
        $stmt->bindParam(':photo', $photo);
        return $stmt->execute();
    }

   
    public function supprimerHebergement($id) {
        $query = "DELETE FROM hebergements WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

   
    public function ajouterHebergement($nom, $adresse, $prix, $etoiles, $photo) {
        try {
            $query = "INSERT INTO hebergements (nom, adresse, prix, etoiles, photo) VALUES (:nom, :adresse, :prix, :etoiles, :photo)";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':nom', $nom);
            $stmt->bindParam(':adresse', $adresse);
            $stmt->bindParam(':prix', $prix);
            $stmt->bindParam(':etoiles', $etoiles);
            $stmt->bindParam(':photo', $photo);
    
            return $stmt->execute();
        } catch (PDOException $e) {
            echo "Erreur lors de l'ajout : " . $e->getMessage();
            return false;
        }
    }
    
    
}
