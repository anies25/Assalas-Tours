<?php
require_once 'Client.php';
require_once _DIR_ . '/../config/database.php';

class Reservation {
    private $id;
    private $date;
    private $client;
    private $details;
    private $statut;

    public function __construct($id, $date, Client $client, $details, $statut = 'confirmée') {
        $this->id = $id;
        $this->date = $date;
        $this->client = $client;
        $this->details = $details;
        $this->statut = $statut;
    }

    public function getId() {
        return $this->id;
    }

    public function getDate() {
        return $this->date;
    }

    public function getClient() {
        return $this->client;
    }

    public function getDetails() {
        return $this->details;
    }

    public function getStatut() {
        return $this->statut;
    }

    public static function getAllReservations() {
        $pdo = Database::getInstance();
        $stmt = $pdo->query("SELECT * FROM reservations");
        $reservations = [];
        while ($row = $stmt->fetch()) {
            $client = new Client($row['client_id'], $row['nom'], $row['prenom'], $row['email'], '');
            $reservations[] = new Reservation($row['id'], $row['date'], $client, $row['details'], $row['statut']);
        }
        return $reservations;
    }
}
?>