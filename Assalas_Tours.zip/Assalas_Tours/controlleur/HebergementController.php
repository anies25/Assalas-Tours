<?php
require_once '../models/HebergementModel.php';
require_once '../config/database.php';

class HebergementController {
    private $hebergementModel;

    public function __construct() {
        $this->hebergementModel = new Hebergement();
    }

 
    public function afficherHebergements($page = 1, $itemsPerPage = 6) {
        $database = new Database();
        $conn = $database->getConnection();

        $offset = ($page - 1) * $itemsPerPage;

      
        $totalHebergements = $this->hebergementModel->getTotalCount($conn);

       
        $hebergements = $this->hebergementModel->getHebergementsByPage($conn, $offset, $itemsPerPage);

       
        $totalPages = ceil($totalHebergements / $itemsPerPage);

       
        include '../views/hebergement.php';
    }
}


if (isset($_GET['action'])) {
    $controller = new HebergementController();

    if ($_GET['action'] === 'afficher') {
        $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        $controller->afficherHebergements($page);
    }
}
?>