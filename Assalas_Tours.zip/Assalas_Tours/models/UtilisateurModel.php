<?php
require_once '../config/database.php';
require_once '../classe/Utilisateur.php';

class UtilisateurModel {
    private $conn;

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

  
    public function verifierEmail($email) {
        $query = "SELECT COUNT(*) FROM utilisateurs WHERE email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        return $stmt->fetchColumn() > 0;
    }


    public function ajouterUtilisateur(Utilisateur $utilisateur) {
        try {
            if ($this->verifierEmail($utilisateur->getEmail())) {
                echo "Cet email est déjà utilisé.";
                return false;
            }
    
            $query = "INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role) VALUES (:nom, :prenom, :email, :motdepasse, :role)";
            $stmt = $this->conn->prepare($query);
    
            $hashedPassword = password_hash($utilisateur->getMotdepasse(), PASSWORD_DEFAULT);
            $stmt->bindParam(':nom', $utilisateur->getNom());
            $stmt->bindParam(':prenom', $utilisateur->getPrenom());
            $stmt->bindParam(':email', $utilisateur->getEmail());
            $stmt->bindParam(':motdepasse', $hashedPassword);
            $stmt->bindParam(':role', $utilisateur->getRole());
    
            if ($stmt->execute()) {
                return true;
            } else {
                echo "Erreur SQL : ";
                print_r($stmt->errorInfo());
                return false;
            }
        } catch (PDOException $e) {
            echo "Erreur PDO : " . $e->getMessage();
            return false;
        }
    }
    
    
    

  
    public function verifierConnexion($email, $motDePasse) {
        $query = "SELECT * FROM utilisateurs WHERE email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        $utilisateur = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($utilisateur && password_verify($motDePasse, $utilisateur['mot_de_passe'])) {
            return $utilisateur;
        }
        return false;
    }

    public function getAllUtilisateurs() {
        $query = "SELECT * FROM utilisateurs";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

   
    public function modifierUtilisateur($id, $nom, $prenom, $email, $role) {
        $query = "UPDATE utilisateurs SET nom = :nom, prenom = :prenom, email = :email, role = :role WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':nom', $nom);
        $stmt->bindParam(':prenom', $prenom);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':role', $role);
        return $stmt->execute();
    }

    public function supprimerUtilisateur($id) {
        $query = "DELETE FROM utilisateurs WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        return $stmt->execute();
    }

  
    public function getUtilisateurById($id) {
        $query = "SELECT * FROM utilisateurs WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

  
    public function genererTokenMotDePasse($email) {
        $token = bin2hex(random_bytes(16)); 
        $query = "UPDATE utilisateurs SET reset_token = :token, reset_token_expiry = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':token', $token);
        $stmt->bindParam(':email', $email);
        if ($stmt->execute()) {
            return $token;
        }
        return false;
    }

   
    public function verifierToken($token) {
        $query = "SELECT * FROM utilisateurs WHERE reset_token = :token AND reset_token_expiry > NOW()";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':token', $token);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    
    public function reinitialiserMotDePasse($token, $nouveauMotDePasse) {
        $nouveauMotDePasseHashe = password_hash($nouveauMotDePasse, PASSWORD_DEFAULT);
        $query = "UPDATE utilisateurs SET mot_de_passe = :motdepasse, reset_token = NULL, reset_token_expiry = NULL WHERE reset_token = :token";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':motdepasse', $nouveauMotDePasseHashe);
        $stmt->bindParam(':token', $token);
        return $stmt->execute();
    }

    public function trouverParEmail($email) {
        $query = "SELECT * FROM utilisateurs WHERE email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC); 
    }


    public function sauvegarderToken($userId, $token) {
        $query = "UPDATE utilisateurs SET reset_token = :reset_token, reset_token_expiry = :reset_token_expiry WHERE id = :id";
        $stmt = $this->conn->prepare($query);
    
        $expiryTime = date('Y-m-d H:i:s', strtotime('+1 hour')); 
        $stmt->bindParam(':reset_token', $token);
        $stmt->bindParam(':reset_token_expiry', $expiryTime);
        $stmt->bindParam(':id', $userId, PDO::PARAM_INT);
    
        return $stmt->execute();
    }
    

    public function trouverParToken($token) {
        $query = "SELECT * FROM utilisateurs WHERE reset_token = :reset_token AND reset_token_expiry > NOW()";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':reset_token', $token);
        $stmt->execute();
    
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    

    public function supprimerToken($idUtilisateur) {
        $query = "UPDATE utilisateurs SET reset_token = NULL, reset_token_expiry = NULL WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $idUtilisateur, PDO::PARAM_INT);
        $stmt->execute();
    }

    public function mettreAJourMotDePasse($idUtilisateur, $nouveauMotDePasse) {
        $query = "UPDATE utilisateurs SET mot_de_passe = :motdepasse WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':motdepasse', $nouveauMotDePasse);
        $stmt->bindParam(':id', $idUtilisateur, PDO::PARAM_INT);
        $stmt->execute();
    }
    
    
    
    
    
}
?>
