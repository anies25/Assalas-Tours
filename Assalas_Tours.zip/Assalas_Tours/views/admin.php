<?php
session_start();
require_once '../models/UtilisateurModel.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: connexion.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Espace Administrateur</title>
    <link rel="stylesheet" href="../public/style.css">
</head>
<body>
<div class="admin-dashboard">
    <aside class="sidebar">
        <div class="sidebar-header">
            <h2>Espace Admin</h2>
        </div>
        <nav>
            <ul>
                <li><a href="admin_hebergement.php">Gérer les hébergements</a></li>
                <li><a href="admin_utilisateur.php">Gérer les utilisateurs</a></li>
                <li><a href="gerer_circuits.php">Gérer les circuits</a></li>
                <li><a href="gerer_vols.php">Gérer les vols</a></li>
            </ul>
        </nav>
    </aside>
    <main class="main-content">
        <header class="main-header">
            <h1>Bienvenue, Admin</h1>
        </header>
        <section class="content">
    <p>Sélectionnez une option dans le menu pour commencer.</p>
    <img src="../public/Image/publicite_11.jpg" alt="Illustration espace admin" class="admin-image">
</section>

    </main>
</div>
</body>
</html>
