<?php
require_once '../models/UtilisateurModel.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $utilisateurModel = new UtilisateurModel();

    if ($utilisateurModel->supprimerUtilisateur($id)) {
       
        header("Location: admin_utilisateur.php");
        exit;
    } else {
        echo "Erreur : Impossible de supprimer l'utilisateur.";
    }
} else {
    echo "Erreur : ID d'utilisateur manquant.";
    exit;
}
?>
