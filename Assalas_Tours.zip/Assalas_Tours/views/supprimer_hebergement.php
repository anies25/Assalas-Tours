<?php
require_once '../models/HebergementModel.php';


session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../views/connexion.php");
    exit;
}


if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $hebergementModel = new HebergementModel();

    if ($hebergementModel->supprimerHebergement($id)) {
        echo "Hébergement supprimé avec succès.";
        header("Location: admin_hebergement.php");
        exit;
    } else {
        echo "Erreur lors de la suppression de l'hébergement.";
    }
} else {
    echo "ID de l'hébergement manquant.";
}
?>
